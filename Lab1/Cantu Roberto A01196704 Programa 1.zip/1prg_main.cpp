#include <iostream>
#include "ReadFile.h"

using namespace std;

int main(){
    string fileName;
    cin >> fileName;
    ReadFile obj(fileName);


    return 0;
}