#include <iostream>
#include "ReadFile.h"
using namespace std;
//.b=8
//.i
int main(){
    string fileName;
    cin >> fileName;
    ReadFile obj(fileName);
    return 0;
};